package com.example.coursat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Sighup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sighup);
    }
}
