package com.reload.coursat.ServiceProvider;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.reload.coursat.R;

import java.util.ArrayList;

public class ServiceProviderActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;
    ArrayList<String> mList;
    ResultsAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_results);
        initViews();
    }

    private void initViews() {

        mRecyclerView = findViewById(R.id.results_rv);
        mList = new ArrayList<>();
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");


        mAdapter = new ResultsAdapter(mList, this);
        mRecyclerView.setAdapter(mAdapter);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        mRecyclerView.setLayoutManager(layoutManager);

    }
}