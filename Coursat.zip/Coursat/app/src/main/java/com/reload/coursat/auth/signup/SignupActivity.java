package com.reload.coursat.auth.signup;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.reload.coursat.R;
import com.reload.coursat.auth.login.LoginActivity;
import com.reload.coursat.common.db.SessionManagment;
import com.reload.coursat.home.HomeActivity;
import com.reload.coursat.model.AuthResponse;
import com.reload.coursat.network.ApiService;
import com.reload.coursat.network.WebServiceClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignupActivity extends AppCompatActivity implements View.OnClickListener {
    EditText mFnameET, mLnameET, mEmailET, mPhoneET, mPassET;
    Button mSignUpBtn, mLoginBtn;
    SessionManagment mSessionManagment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mSessionManagment = new SessionManagment(SignupActivity.this);
        initViews();
    }

    private void initViews() {
        mFnameET = findViewById(R.id.fname_et);
        mLnameET = findViewById(R.id.lname_et);
        mEmailET = findViewById(R.id.email_et);
        mPhoneET = findViewById(R.id.phone_et);
        mPassET = findViewById(R.id.pass_et);
        mSignUpBtn = findViewById(R.id.signup_btn);
        mLoginBtn = findViewById(R.id.login_btn);
        mSignUpBtn.setOnClickListener(this);
        mLoginBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.signup_btn:
                if (isDataValid())
                    callRegisterApi();
                break;
            case R.id.login_btn:
                startActivity(new Intent(SignupActivity.this, LoginActivity.class));
                break;
        }
    }

    Boolean isDataValid() {
        if (mFnameET.getText().toString().isEmpty()) {
            Toast.makeText(this, "please enter your first name", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mLnameET.getText().toString().isEmpty()) {
            Toast.makeText(this, "please enter your last name", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mEmailET.getText().toString().isEmpty()) {
            Toast.makeText(this, "please enter your Email", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mPhoneET.getText().toString().isEmpty()) {
            Toast.makeText(this, "please enter your phone", Toast.LENGTH_SHORT).show();
            return false;
        } else if (mPassET.getText().toString().isEmpty()) {
            Toast.makeText(this, "please enter your pass", Toast.LENGTH_SHORT).show();
            return false;
        } else {
            return true;
        }
    }

    private void callRegisterApi() {

        ApiService apiService = WebServiceClient.getRetrofit().create(ApiService.class);
        Call<AuthResponse> call = apiService.register(mFnameET.getText().toString()
                , mLnameET.getText().toString()
                , mEmailET.getText().toString()
                , mPhoneET.getText().toString());
        call.enqueue(new Callback<AuthResponse>() {
            @Override
            public void onResponse(Call<AuthResponse> call, Response<AuthResponse> response) {

                if (response.body().getStatus()) {
                    mSessionManagment.saveData(response.body().getResult().get(0).getFirstName()
                            , response.body().getResult().get(0).getLastName()
                            , response.body().getResult().get(0).getEmail()
                            , response.body().getResult().get(0).getPhone()
                            , response.body().getStatus());

                    startActivity(new Intent(SignupActivity.this, HomeActivity.class));
                    SignupActivity.this.finish();
                } else
                    Toast.makeText(SignupActivity.this, response.body().getMsg(), Toast.LENGTH_LONG).show();
            }

            @Override
            public void onFailure(Call<AuthResponse> call, Throwable t) {
                Log.e("fail", t.getMessage());
            }
        });
    }


}
