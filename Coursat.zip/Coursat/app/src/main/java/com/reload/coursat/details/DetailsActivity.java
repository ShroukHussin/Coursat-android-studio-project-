package com.reload.coursat.details;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.reload.coursat.R;

public class DetailsActivity extends AppCompatActivity implements View.OnClickListener {
    TextView academyAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        initViews();
    }

    private void initViews() {
       // academyAddress = findViewById(R.id.address_tv);
        academyAddress.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
           // case R.id.address_tv:
               // startActivity(new Intent(DetailsActivity.this, MapsActivity.class));
               // break;
        }
    }
}
