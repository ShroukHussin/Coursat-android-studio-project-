package com.reload.coursat.details.contactUs;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.reload.coursat.R;

public class ContactActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
    }
}
