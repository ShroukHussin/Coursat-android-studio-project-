package com.reload.coursat.home;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.reload.coursat.R;
import com.reload.coursat.favourites.FavFragment;
import com.reload.coursat.home.homeFragment.HomeFragment;
import com.reload.coursat.offers.OffersFragment;
import com.reload.coursat.settings.SettingsFragment;

public class HomeActivity extends AppCompatActivity implements View.OnClickListener {
    BottomNavigationView navigation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        initViews();
        navigatFragment(new HomeFragment());
    }

    private void initViews() {
        navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

    }

    @Override
    public void onClick(View v) {

    }


    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.home:
                    navigatFragment(new HomeFragment());
                    return true;
                case R.id.fav_item:
                    navigatFragment(new FavFragment());
                    return true;
                case R.id.offers_item:
                    navigatFragment(new OffersFragment());
                    return true;
                case R.id.settings_item:
                    navigatFragment(new SettingsFragment());
                    return true;
            }
            return false;
        }
    };



    void navigatFragment(Fragment fragment){
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.page_container,fragment).commit();
    }
}