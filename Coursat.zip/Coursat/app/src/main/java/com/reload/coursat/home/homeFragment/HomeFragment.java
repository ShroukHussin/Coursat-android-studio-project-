package com.reload.coursat.home.homeFragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.reload.coursat.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    View view;
    RecyclerView mRecyclerView;
    ArrayList<HomeModel> mList;
    HomeAdapter mAdapter;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_home, container, false);
        initViews();
        return view;
    }

    private void initViews() {
        mRecyclerView = view.findViewById(R.id.home_rv);
        mList = new ArrayList<>();
        mList.add(new HomeModel("Academies", R.drawable.co));
        mList.add(new HomeModel("Private Trainer", R.drawable.co));
        mList.add(new HomeModel("Online Courses", R.drawable.co));
        mList.add(new HomeModel("Group Discussion", R.drawable.co));
        mAdapter = new HomeAdapter(mList, getActivity());
        mRecyclerView.setAdapter(mAdapter);

        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(getActivity(), 2);
        mRecyclerView.setLayoutManager(layoutManager);

    }

}
