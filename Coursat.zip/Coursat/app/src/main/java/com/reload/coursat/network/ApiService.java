package com.reload.coursat.network;

import com.reload.coursat.model.AuthResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {

    @POST("register")
    @FormUrlEncoded
    Call<AuthResponse> register (@Field("first_name") String userFname ,
                                 @Field("last_name") String userLname,
                                 @Field("email") String userEmail,
                                 @Field("phone")  String userPhone);

    @POST("login")
    @FormUrlEncoded
    Call<AuthResponse> login (@Field("email") String userEmail);
}
