package com.reload.coursat.offers;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.reload.coursat.R;

import java.util.ArrayList;

public class OffersAdapter extends RecyclerView.Adapter<OffersAdapter.MyViewHolder> {

        ArrayList<String> mList ;
        Context mContext;

public OffersAdapter(ArrayList<String> mList, Context mContext) {
        this.mList = mList;
        this.mContext = mContext;
        }

@Override
public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
        .inflate(R.layout.offers_item,parent,false);
    OffersAdapter.MyViewHolder myViewHolder = new OffersAdapter.MyViewHolder(view);
        return myViewHolder;
        }

@Override
public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        }

@Override
public int getItemCount() {
        return mList.size();
        }

class MyViewHolder extends RecyclerView.ViewHolder {

    public MyViewHolder(@NonNull View itemView) {
        super(itemView);


    }
}
}