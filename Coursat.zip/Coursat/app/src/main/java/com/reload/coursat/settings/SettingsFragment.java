package com.reload.coursat.settings;


import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.reload.coursat.R;
import com.reload.coursat.settings.editProfile.EditProfileActivity;
import com.reload.coursat.settings.logOut.LogOutFragment;

/**
 * A simple {@link Fragment} subclass.
 */
public class SettingsFragment extends Fragment implements View.OnClickListener {
    View view;
    TextView editProfile,changePass,contactUs,rateApp,shareApp,logOut;

    public SettingsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_settings, container, false);
        initiViews();
        return view;
    }

    private void initiViews() {
        logOut = view.findViewById(R.id.logOut_tv);
        logOut.setOnClickListener(this);
        editProfile = view.findViewById(R.id.edit_profile_tv);
        editProfile.setOnClickListener(this);
        changePass = view.findViewById(R.id.change_pass_tv);
        changePass.setOnClickListener(this);
        contactUs = view.findViewById(R.id.contact_us_tv);
        contactUs.setOnClickListener(this);
        rateApp = view.findViewById(R.id.rate_app_tv);
        rateApp.setOnClickListener(this);
        shareApp = view.findViewById(R.id.share_app_tv);
        shareApp.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.logOut_tv:
                LogOutFragment logOutFragment = new LogOutFragment();
                logOutFragment.show(getFragmentManager(), "");
                break;
            case R.id.edit_profile_tv:
                 startActivity(new Intent(getActivity(), EditProfileActivity.class));
                break;

            case R.id.change_pass_tv:

                break;

            case R.id.rate_app_tv:

                break;

            case R.id.share_app_tv:

                break;
        }
    }
}
