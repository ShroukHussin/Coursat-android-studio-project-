package com.reload.coursat.settings.editProfile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.reload.coursat.R;
import com.reload.coursat.common.db.SessionManagment;

public class EditProfileActivity extends AppCompatActivity implements View.OnClickListener {
    EditText mEmail, mPass;
    Button save;
  SessionManagment mSessionManagment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);
        mSessionManagment=new SessionManagment(EditProfileActivity.this);
        intiViews();
    }

    private void intiViews() {
        mEmail = findViewById(R.id.email_et);
        mPass = findViewById(R.id.email_et);
        save = findViewById(R.id.save_btn);
        save.setOnClickListener(this);
    }


    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.save_btn:


                break;
        }
    }
}
