package com.reload.coursat.settings.logOut;


import android.os.Bundle;
import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import com.reload.coursat.R;
import com.reload.coursat.common.db.SessionManagment;


/**
 * A simple {@link Fragment} subclass.
 */
public class LogOutFragment extends AppCompatDialogFragment implements View.OnClickListener {

    View view;
    Button cancelBtn , logOutBtn;
    SessionManagment sessionManagment;

    public LogOutFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_log_out, container, false);
        intiViews();
        return view;
    }

    private void intiViews() {
        cancelBtn=view.findViewById(R.id.cancelBtn);
        cancelBtn.setOnClickListener(this);
        logOutBtn=view.findViewById(R.id.logOutBtn);
        logOutBtn.setOnClickListener(this);
        sessionManagment=new SessionManagment(view.getContext());
    }

    @Override
    public void onClick(View view) {
        switch (view.getId())
        {
            case R.id.cancelBtn:

                break;
            case R.id.logOutBtn:
                sessionManagment.logOut();
                break;
        }

    }
}
