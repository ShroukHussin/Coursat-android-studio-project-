package com.reload.coursat.splash;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.reload.coursat.R;
import com.reload.coursat.auth.login.LoginActivity;
import com.reload.coursat.auth.signup.SignupActivity;
import com.reload.coursat.common.db.SessionManagment;
import com.reload.coursat.home.HomeActivity;

public class SplashActivity extends AppCompatActivity {
    SessionManagment mSessionManagment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        mSessionManagment = new SessionManagment(this);
        splashTimer();
        finish();
    }

    private void splashTimer() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSessionManagment.isLogin()) {
                    startActivity(new Intent(SplashActivity.this, HomeActivity.class));
                    SplashActivity.this.finish();
                } else {
                    startActivity(new Intent(SplashActivity.this, LoginActivity.class));
                    SplashActivity.this.finish();
                }
            }
        }, 2000);

    }
}
