package com.reload.coursat.subCat;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.reload.coursat.R;

import java.util.ArrayList;

public class SubCatActivity extends AppCompatActivity {
    RecyclerView mRecyclerView;
    ArrayList<String> mList;
    SubCatAdapter mAdapter;
    TextView mPageTitle;
    ImageView showResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_cat);
        initViews();
    }

    private void initViews() {
        Intent i = getIntent();
        mPageTitle = findViewById(R.id.page_title);
        mPageTitle.setText(i.getStringExtra("title"));
        mPageTitle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        mRecyclerView = findViewById(R.id.sub_cat_rv);
        showResult = findViewById(R.id.show_result);
        mList = new ArrayList<>();
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");
        mList.add("");


        mAdapter = new SubCatAdapter(mList, this);
        mRecyclerView.setAdapter(mAdapter);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        mRecyclerView.setLayoutManager(layoutManager);

    }


}
