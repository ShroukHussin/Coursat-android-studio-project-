package com.shrouq.coursat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.reload.coursat.R;

public class signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }
}
